import { useState, useEffect } from 'react';
import { Link, Outlet, useLocation } from 'react-router';
import { Menu, X, Sun, Moon, Type, MessageCircle } from 'lucide-react';
import { LiveChat } from './LiveChat';
import { useTheme } from './ThemeContext';

export function Layout() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [fontSize, setFontSize] = useState(16);
  const [highContrast, setHighContrast] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const { darkMode, toggleDarkMode } = useTheme();
  const location = useLocation();

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    document.documentElement.style.fontSize = `${fontSize}px`;
  }, [fontSize]);

  useEffect(() => {
    if (highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
  }, [highContrast]);

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/about', label: 'About' },
    { to: '/speakers', label: 'Speakers' },
    { to: '/venue', label: 'Venue' },
    { to: '/schedule', label: 'Schedule' },
    { to: '/registration', label: 'Register' },
    { to: '/sponsors', label: 'Sponsors' },
    { to: '/faq', label: 'FAQ' },
  ];

  const userName = localStorage.getItem('paraiso_user');
  const isLoggedIn = !!userName;

  const handleLogout = () => {
    localStorage.removeItem('paraiso_user');
    localStorage.removeItem('paraiso_user_id');
    localStorage.removeItem('paraiso_user_email');
    window.location.href = '/';
  };

  return (
    <div className={`min-h-screen ${highContrast ? 'bg-black text-white' : 'bg-white'}`}>
      {/* Header */}
      <header className="sticky top-0 z-50 bg-black text-white shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2">
              <div className="text-3xl font-bold bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent">
                PARAISO
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`text-sm font-medium hover:text-yellow-400 transition-colors ${
                    location.pathname === link.to ? 'text-yellow-400' : 'text-white'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* Accessibility Controls */}
            <div className="hidden lg:flex items-center space-x-4">
              {isLoggedIn ? (
                <>
                  <Link
                    to="/bookings"
                    className="px-4 py-2 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold rounded-lg hover:from-yellow-400 hover:to-amber-500 transition-all text-sm"
                  >
                    My Bookings
                  </Link>
                  <div className="text-sm text-gray-400">
                    Hi, {userName}
                  </div>
                  <button
                    onClick={handleLogout}
                    className="text-sm text-gray-400 hover:text-yellow-400 transition-colors"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  className="px-4 py-2 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold rounded-lg hover:from-yellow-400 hover:to-amber-500 transition-all text-sm"
                >
                  Login
                </Link>
              )}
              <button
                onClick={() => setFontSize(Math.max(12, fontSize - 2))}
                className="p-2 hover:bg-gray-800 rounded"
                title="Decrease font size"
              >
                <Type className="w-4 h-4" />
              </button>
              <button
                onClick={() => setFontSize(Math.min(24, fontSize + 2))}
                className="p-2 hover:bg-gray-800 rounded"
                title="Increase font size"
              >
                <Type className="w-6 h-6" />
              </button>
              <button
                onClick={toggleDarkMode}
                className="p-2 hover:bg-gray-800 rounded"
                title="Toggle dark mode"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <nav className="lg:hidden py-4 space-y-2">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`block py-2 px-4 hover:bg-gray-800 rounded ${
                    location.pathname === link.to ? 'text-yellow-400 bg-gray-800' : 'text-white'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <div className="flex items-center space-x-4 px-4 pt-4 border-t border-gray-700">
                <button
                  onClick={() => setFontSize(Math.max(12, fontSize - 2))}
                  className="p-2 hover:bg-gray-800 rounded"
                  title="Decrease font size"
                >
                  <Type className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setFontSize(Math.min(24, fontSize + 2))}
                  className="p-2 hover:bg-gray-800 rounded"
                  title="Increase font size"
                >
                  <Type className="w-6 h-6" />
                </button>
                <button
                  onClick={toggleDarkMode}
                  className="p-2 hover:bg-gray-800 rounded"
                  title="Toggle dark mode"
                >
                  {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                </button>
              </div>
            </nav>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main>
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-black text-white py-12 mt-20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent mb-4">
                PARAISO
              </h3>
              <p className="text-gray-400">
                The premier conference experience for industry leaders and innovators.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><Link to="/about" className="text-gray-400 hover:text-yellow-400">About Event</Link></li>
                <li><Link to="/schedule" className="text-gray-400 hover:text-yellow-400">Schedule</Link></li>
                <li><Link to="/speakers" className="text-gray-400 hover:text-yellow-400">Speakers</Link></li>
                <li><Link to="/registration" className="text-gray-400 hover:text-yellow-400">Register</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>info@paraiso.com</li>
                <li>+1 (555) 123-4567</li>
                <li>123 Conference Ave</li>
                <li>Miami, FL 33139</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Newsletter</h4>
              <p className="text-gray-400 mb-4">Stay updated with event news</p>
              <form className="flex flex-col space-y-2">
                <input
                  type="email"
                  placeholder="Your email"
                  className="px-4 py-2 bg-gray-800 border border-gray-700 rounded focus:outline-none focus:border-yellow-400"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-semibold rounded hover:from-yellow-400 hover:to-amber-500 transition-all"
                >
                  Subscribe
                </button>
              </form>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
            <p>&copy; 2026 PARAISO Conference. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Live Chat Widget */}
      <button
        onClick={() => setChatOpen(!chatOpen)}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-yellow-500 to-amber-600 text-black p-4 rounded-full shadow-lg hover:from-yellow-400 hover:to-amber-500 transition-all z-50"
        title="Open live chat"
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {chatOpen && <LiveChat onClose={() => setChatOpen(false)} />}
    </div>
  );
}