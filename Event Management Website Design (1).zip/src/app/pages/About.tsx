import { Target, Eye, Heart, Users, Lightbulb, Globe } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function About() {
  const values = [
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'Fostering breakthrough ideas and cutting-edge solutions that shape the future.',
    },
    {
      icon: Users,
      title: 'Community',
      description: 'Building lasting connections among professionals, leaders, and innovators.',
    },
    {
      icon: Globe,
      title: 'Global Impact',
      description: 'Creating positive change that resonates across industries and borders.',
    },
    {
      icon: Heart,
      title: 'Excellence',
      description: 'Delivering world-class experiences with uncompromising quality and attention to detail.',
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1728933102332-a4f1a281a621?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZW1pbmFyJTIwYXVkaWVuY2UlMjB3b3Jrc2hvcHxlbnwxfHx8fDE3NzE0MDg1NTh8MA&ixlib=rb-4.1.0&q=80&w=1080"
            alt="Conference"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/60 to-amber-900/40"></div>
        </div>
        <div className="relative z-10 container mx-auto px-4 text-center">
          <h1 className="text-6xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent">
            About PARAISO
          </h1>
          <p className="text-xl md:text-2xl text-white max-w-3xl mx-auto">
            Where visionaries gather to shape tomorrow's innovations
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12">
            <div className="bg-gradient-to-br from-yellow-50 to-amber-50 p-12 rounded-lg border-2 border-yellow-300">
              <Target className="w-16 h-16 text-yellow-600 mb-6" />
              <h2 className="text-4xl font-bold mb-6 text-black">Our Mission</h2>
              <p className="text-gray-700 text-lg leading-relaxed">
                To create an unparalleled platform where industry leaders, innovators, and changemakers converge to share insights, forge partnerships, and drive transformative change across global industries. We are committed to fostering an environment of learning, collaboration, and inspiration that empowers attendees to achieve their highest potential.
              </p>
            </div>
            <div className="bg-gradient-to-br from-gray-900 to-black p-12 rounded-lg border-2 border-yellow-500">
              <Eye className="w-16 h-16 text-yellow-400 mb-6" />
              <h2 className="text-4xl font-bold mb-6 text-white">Our Vision</h2>
              <p className="text-gray-300 text-lg leading-relaxed">
                To be recognized globally as the premier conference experience that catalyzes innovation, builds meaningful connections, and shapes the future of business and technology. We envision PARAISO as the ultimate destination where groundbreaking ideas transform into reality and where every attendee leaves empowered to make a lasting impact.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-gradient-to-br from-gray-900 via-black to-amber-900/20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-5xl font-bold mb-6 text-white">Our Story</h2>
              <div className="space-y-4 text-gray-300 text-lg leading-relaxed">
                <p>
                  Founded in 2020, PARAISO was born from a vision to create more than just another conference—we set out to build an experience that would redefine how professionals connect, learn, and grow together.
                </p>
                <p>
                  What started as a modest gathering of 500 passionate individuals has evolved into one of the most anticipated events in the industry calendar, attracting over 5,000 attendees from around the globe.
                </p>
                <p>
                  Our name, PARAISO (Spanish for "paradise"), reflects our commitment to creating an ideal environment where innovation flourishes, connections deepen, and careers transform. Every aspect of our conference is carefully curated to provide attendees with an extraordinary experience.
                </p>
                <p>
                  Over the past six years, we've hosted hundreds of world-renowned speakers, facilitated thousands of meaningful partnerships, and witnessed countless breakthrough moments that have shaped industries worldwide.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1761388559873-40bfb05f39e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjb25mZXJlbmNlJTIwcm9vbSUyMHByZXNlbnRhdGlvbnxlbnwxfHx8fDE3NzE0MDg1NTV8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Conference room"
                className="w-full h-64 object-cover rounded-lg"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1764173039056-3cc602fef942?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwYW5lbCUyMGRpc2N1c3Npb258ZW58MXx8fHwxNzcxNDA4NTU4fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Panel discussion"
                className="w-full h-64 object-cover rounded-lg mt-8"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1635468073086-7edff555234a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25mZXJlbmNlJTIwd29ya3Nob3AlMjBpbnRlcmFjdGl2ZSUyMHNlc3Npb258ZW58MXx8fHwxNzcxNDA4NTU5fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Workshop"
                className="w-full h-64 object-cover rounded-lg -mt-8"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1771154139725-f2b0b4891430?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxldmVudCUyMGNhdGVyaW5nJTIwYnVmZmV0fGVufDF8fHx8MTc3MTQwODU1OHww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Event catering"
                className="w-full h-64 object-cover rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-center mb-4 text-black">Our Core Values</h2>
          <p className="text-center text-gray-600 mb-16 text-xl">
            The principles that guide everything we do
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div
                  key={index}
                  className="p-8 bg-gradient-to-br from-yellow-50 to-white border-2 border-yellow-200 rounded-lg hover:border-yellow-400 hover:shadow-lg transition-all"
                >
                  <Icon className="w-12 h-12 text-yellow-600 mb-4" />
                  <h3 className="text-2xl font-bold mb-3 text-black">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* What Makes Us Different */}
      <section className="py-20 bg-gradient-to-br from-yellow-500 via-amber-600 to-yellow-500">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-center mb-16 text-black">What Makes Us Different</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: 'Curated Content',
                description: 'Every session is meticulously selected to deliver maximum value and actionable insights.',
              },
              {
                title: 'World-Class Speakers',
                description: 'Learn from industry pioneers, thought leaders, and visionaries who are shaping the future.',
              },
              {
                title: 'Premium Networking',
                description: 'Connect with like-minded professionals in an environment designed for meaningful interactions.',
              },
              {
                title: 'Exclusive Experiences',
                description: 'From VIP dinners to private workshops, we offer unique opportunities beyond the main event.',
              },
              {
                title: 'Cutting-Edge Venue',
                description: 'State-of-the-art facilities with the latest technology to enhance your conference experience.',
              },
              {
                title: 'Lasting Impact',
                description: 'Take home insights, connections, and inspiration that will transform your career and business.',
              },
            ].map((item, index) => (
              <div
                key={index}
                className="bg-black/20 backdrop-blur-sm p-8 rounded-lg border-2 border-black/30 hover:bg-black/30 transition-all"
              >
                <h3 className="text-2xl font-bold mb-4 text-black">{item.title}</h3>
                <p className="text-black/80">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* By the Numbers */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-center mb-16 text-white">PARAISO By the Numbers</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { number: '6', label: 'Years of Excellence' },
              { number: '5000+', label: 'Attendees Annually' },
              { number: '200+', label: 'Expert Speakers' },
              { number: '50+', label: 'Countries Represented' },
              { number: '100+', label: 'Sessions & Workshops' },
              { number: '30+', label: 'Industry Partners' },
              { number: '10K+', label: 'Connections Made' },
              { number: '98%', label: 'Satisfaction Rate' },
            ].map((stat, index) => (
              <div key={index} className="text-center p-8 bg-gradient-to-br from-yellow-500/10 to-amber-600/10 border border-yellow-500/30 rounded-lg">
                <div className="text-5xl font-bold text-yellow-400 mb-2">{stat.number}</div>
                <div className="text-white">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
