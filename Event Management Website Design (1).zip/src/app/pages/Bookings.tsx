import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Download, Printer, Calendar, MapPin, Users, Ticket } from 'lucide-react';
import { useTheme } from '../components/ThemeContext';

interface Booking {
  id: string;
  eventType: string;
  venue: string;
  date: string;
  package: string;
  price: number;
  ticketType: string;
  quantity: number;
  userName: string;
  userEmail: string;
  timestamp: string;
}

export function Bookings() {
  const { darkMode } = useTheme();
  const navigate = useNavigate();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [timeLeft, setTimeLeft] = useState<{ [key: string]: { days: number; hours: number; minutes: number; seconds: number } }>({});

  useEffect(() => {
    // Check if user is logged in
    const userId = localStorage.getItem('paraiso_user_id');
    if (!userId) {
      navigate('/login?from=/bookings');
      return;
    }

    // Load bookings from localStorage
    const allBookings = JSON.parse(localStorage.getItem('paraiso_bookings') || '[]');
    const userBookings = allBookings.filter((b: Booking) => b.id.startsWith(userId));
    setBookings(userBookings);
  }, [navigate]);

  // Countdown timer for each booking
  useEffect(() => {
    const updateTimers = () => {
      const newTimeLeft: { [key: string]: any } = {};
      
      bookings.forEach((booking) => {
        const eventDate = new Date(booking.date + 'T00:00:00').getTime();
        const now = new Date().getTime();
        const difference = eventDate - now;

        if (difference > 0) {
          newTimeLeft[booking.id] = {
            days: Math.floor(difference / (1000 * 60 * 60 * 24)),
            hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
            minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
            seconds: Math.floor((difference % (1000 * 60)) / 1000),
          };
        } else {
          newTimeLeft[booking.id] = { days: 0, hours: 0, minutes: 0, seconds: 0 };
        }
      });

      setTimeLeft(newTimeLeft);
    };

    if (bookings.length > 0) {
      updateTimers();
      const timer = setInterval(updateTimers, 1000);
      return () => clearInterval(timer);
    }
  }, [bookings]);

  const downloadTicket = (booking: Booking) => {
    // Create a downloadable ticket
    const ticketContent = `
╔══════════════════════════════════════════════════════════════╗
║                          PARAISO 2026                          ║
║                    OFFICIAL EVENT TICKET                       ║
╠══════════════════════════════════════════════════════════════╣
║                                                                ║
║  Booking ID: ${booking.id}                                    
║  Event Type: ${booking.eventType}                             
║  Venue: ${booking.venue}                                      
║  Date: ${new Date(booking.date).toLocaleDateString('en-PH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
║  Package: ${booking.package}                                  
║  Ticket Type: ${booking.ticketType}                           
║  Quantity: ${booking.quantity}                                
║  Total: ₱${booking.price.toLocaleString('en-PH')}             
║                                                                ║
║  Guest Name: ${booking.userName}                              
║  Email: ${booking.userEmail}                                  
║                                                                ║
║  Booked on: ${new Date(booking.timestamp).toLocaleString()}   
║                                                                ║
╠══════════════════════════════════════════════════════════════╣
║  Please present this ticket at the venue entrance.             ║
║  For inquiries: info@paraiso.com | +1 (555) 123-4567          ║
╚══════════════════════════════════════════════════════════════╝
    `;

    const blob = new Blob([ticketContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PARAISO-Ticket-${booking.id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const printSchedule = () => {
    const printContent = `
<!DOCTYPE html>
<html>
<head>
  <title>My PARAISO Schedule</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    h1 { color: #EAB308; text-align: center; }
    .booking { border: 2px solid #EAB308; padding: 15px; margin: 15px 0; border-radius: 10px; }
    .booking h2 { color: #000; margin: 0 0 10px 0; }
    .detail { margin: 5px 0; }
    .label { font-weight: bold; }
  </style>
</head>
<body>
  <h1>🎉 MY PARAISO SCHEDULE 🎉</h1>
  ${bookings.map(booking => `
    <div class="booking">
      <h2>${booking.eventType} - ${booking.venue}</h2>
      <div class="detail"><span class="label">Date:</span> ${new Date(booking.date).toLocaleDateString('en-PH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
      <div class="detail"><span class="label">Package:</span> ${booking.package}</div>
      <div class="detail"><span class="label">Ticket:</span> ${booking.ticketType} x ${booking.quantity}</div>
      <div class="detail"><span class="label">Total:</span> ₱${booking.price.toLocaleString('en-PH')}</div>
      <div class="detail"><span class="label">Booking ID:</span> ${booking.id}</div>
    </div>
  `).join('')}
  <p style="text-align: center; margin-top: 30px; color: #666;">
    For inquiries: info@paraiso.com | +1 (555) 123-4567
  </p>
</body>
</html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const userName = localStorage.getItem('paraiso_user') || 'Guest';

  if (bookings.length === 0) {
    return (
      <div className={`min-h-screen ${darkMode ? 'bg-gray-950' : 'bg-gray-50'} py-20`}>
        <div className="container mx-auto px-4 text-center">
          <div className={`max-w-md mx-auto ${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-2xl shadow-xl p-12`}>
            <Ticket className="w-24 h-24 mx-auto mb-6 text-yellow-500" />
            <h2 className={`text-3xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-black'}`}>No Bookings Yet</h2>
            <p className={`mb-8 ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              You haven't made any bookings yet. Start planning your perfect event!
            </p>
            <button
              onClick={() => navigate('/venue')}
              className="px-8 py-4 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold text-lg rounded-lg hover:from-yellow-400 hover:to-amber-500 transition-all shadow-lg"
            >
              Browse Venues
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      {/* Hero */}
      <section className={`py-20 ${darkMode ? 'bg-gradient-to-br from-gray-900 via-black to-amber-900/10' : 'bg-gradient-to-br from-black via-gray-900 to-amber-900/20'}`}>
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent">
            My Bookings
          </h1>
          <p className="text-xl text-white">Welcome back, {userName}!</p>
        </div>
      </section>

      {/* Actions */}
      <section className={`py-8 ${darkMode ? 'bg-gray-900' : 'bg-white'} border-b ${darkMode ? 'border-gray-800' : 'border-gray-200'}`}>
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap gap-4 justify-center">
            <button
              onClick={printSchedule}
              className="px-6 py-3 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold rounded-lg hover:from-yellow-400 hover:to-amber-500 transition-all shadow-lg flex items-center space-x-2"
            >
              <Printer className="w-5 h-5" />
              <span>Print Schedule</span>
            </button>
          </div>
        </div>
      </section>

      {/* Bookings List */}
      <section className={`py-12 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
        <div className="container mx-auto px-4">
          <div className="grid gap-8 max-w-6xl mx-auto">
            {bookings.map((booking) => (
              <div key={booking.id} className={`${darkMode ? 'bg-gray-800 border-yellow-600/30' : 'bg-white border-yellow-200'} rounded-2xl shadow-xl overflow-hidden border-2`}>
                <div className="bg-gradient-to-r from-yellow-500 to-amber-600 p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="text-3xl font-bold text-black mb-2">{booking.eventType}</h2>
                      <p className="text-black/80 text-lg">{booking.venue}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-black/70">Booking ID</div>
                      <div className="font-mono text-black font-bold">{booking.id.slice(-8)}</div>
                    </div>
                  </div>
                </div>

                <div className="p-8">
                  <div className="grid md:grid-cols-2 gap-8 mb-8">
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <Calendar className="w-5 h-5 text-yellow-500" />
                        <div>
                          <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Event Date</div>
                          <div className={`font-bold ${darkMode ? 'text-white' : 'text-black'}`}>
                            {new Date(booking.date).toLocaleDateString('en-PH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <MapPin className="w-5 h-5 text-yellow-500" />
                        <div>
                          <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Package</div>
                          <div className={`font-bold ${darkMode ? 'text-white' : 'text-black'}`}>{booking.package}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Users className="w-5 h-5 text-yellow-500" />
                        <div>
                          <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Tickets</div>
                          <div className={`font-bold ${darkMode ? 'text-white' : 'text-black'}`}>
                            {booking.ticketType} × {booking.quantity}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Ticket className="w-5 h-5 text-yellow-500" />
                        <div>
                          <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Total Price</div>
                          <div className="font-bold text-2xl text-yellow-600">
                            ₱{booking.price.toLocaleString('en-PH')}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Countdown */}
                    {timeLeft[booking.id] && (
                      <div className={`${darkMode ? 'bg-gray-900/50' : 'bg-yellow-50'} rounded-xl p-6`}>
                        <h3 className={`text-lg font-bold mb-4 text-center ${darkMode ? 'text-white' : 'text-black'}`}>
                          Countdown to Your Event
                        </h3>
                        <div className="grid grid-cols-4 gap-2">
                          {Object.entries(timeLeft[booking.id]).map(([unit, value]) => (
                            <div key={unit} className={`${darkMode ? 'bg-black/50' : 'bg-white'} rounded-lg p-3 text-center border-2 border-yellow-500/30`}>
                              <div className="text-2xl font-bold text-yellow-500">{value.toString().padStart(2, '0')}</div>
                              <div className={`text-xs uppercase mt-1 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{unit}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap gap-4">
                    <button
                      onClick={() => downloadTicket(booking)}
                      className="flex-1 min-w-[200px] px-6 py-3 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold rounded-lg hover:from-yellow-400 hover:to-amber-500 transition-all shadow-lg flex items-center justify-center space-x-2"
                    >
                      <Download className="w-5 h-5" />
                      <span>Download Ticket</span>
                    </button>
                  </div>

                  <div className={`mt-6 pt-6 border-t ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
                    <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      Booked on: {new Date(booking.timestamp).toLocaleString('en-PH')}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
