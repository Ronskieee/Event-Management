import { useState } from 'react';
import { ChevronDown, ChevronUp, Search, HelpCircle } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

const faqs: FAQItem[] = [
  // General
  {
    category: 'General',
    question: 'What is PARAISO Conference?',
    answer: 'PARAISO is a premier three-day conference bringing together industry leaders, innovators, and professionals from around the world. The event features keynote speeches, workshops, networking opportunities, and exhibitions focused on driving innovation and fostering meaningful connections.',
  },
  {
    category: 'General',
    question: 'When and where is PARAISO 2026 taking place?',
    answer: 'PARAISO 2026 will be held from June 15-17, 2026, at the Miami Beach Convention Center in Miami Beach, Florida. The venue is located at 1901 Convention Center Drive, Miami Beach, FL 33139.',
  },
  {
    category: 'General',
    question: 'What are the conference hours?',
    answer: 'The conference runs from 9:00 AM to 6:00 PM each day, with evening networking events and the gala dinner extending until 10:00 PM. Registration opens at 8:00 AM daily.',
  },

  // Registration & Tickets
  {
    category: 'Registration',
    question: 'How do I register for the conference?',
    answer: 'You can register online through our website by visiting the Registration page. Select your ticket type, fill in your details, and complete the payment process. You will receive a confirmation email with your ticket and access details.',
  },
  {
    category: 'Registration',
    question: 'What ticket types are available?',
    answer: 'We offer three ticket types: Early Bird ($499), Standard Pass ($699), and VIP Experience ($1,299). Each tier includes different benefits. Early Bird tickets offer the best value with significant savings. VIP tickets include exclusive access to premium events, priority seating, and speaker meet-and-greets.',
  },
  {
    category: 'Registration',
    question: 'Can I get a refund if I cannot attend?',
    answer: 'Full refunds are available up to 60 days before the event. Between 30-60 days, a 50% refund is available. Within 30 days of the event, tickets are non-refundable but can be transferred to another person by contacting our support team.',
  },
  {
    category: 'Registration',
    question: 'Can I transfer my ticket to someone else?',
    answer: 'Yes, tickets are transferable. Please contact our registration team at registration@paraiso.com with the details of the person receiving the ticket. Transfers must be completed at least 48 hours before the event starts.',
  },
  {
    category: 'Registration',
    question: 'Are group discounts available?',
    answer: 'Yes! We offer group discounts for teams of 5 or more attendees. Contact our sales team at groups@paraiso.com for special pricing and customized packages for your organization.',
  },

  // Event Details
  {
    category: 'Event Details',
    question: 'Is the event virtual, in-person, or hybrid?',
    answer: 'PARAISO 2026 is primarily an in-person event, but select sessions will be available virtually for those who cannot attend in person. Virtual attendees will have access to live-streamed keynotes and select workshops, plus on-demand recordings.',
  },
  {
    category: 'Event Details',
    question: 'What is the dress code?',
    answer: 'Business casual attire is recommended for conference sessions and daytime events. Business formal attire is required for the evening gala dinner on Day 1. Comfortable shoes are strongly recommended as you will be moving between sessions and exhibition areas.',
  },
  {
    category: 'Event Details',
    question: 'Will food be provided?',
    answer: 'Yes! All ticket types include daily lunch, morning and afternoon refreshments, and coffee breaks. VIP ticket holders also have access to the VIP lounge with premium catering. The gala dinner is included for VIP attendees or available as a separate add-on.',
  },
  {
    category: 'Event Details',
    question: 'What are the COVID-19 safety measures?',
    answer: 'We are committed to providing a safe environment. We follow all local health guidelines and venue protocols. Hand sanitizing stations are available throughout the venue. We recommend staying updated on our website for the latest health and safety information closer to the event date.',
  },

  // Speakers & Sessions
  {
    category: 'Speakers & Sessions',
    question: 'How do I choose which sessions to attend?',
    answer: 'Browse our Schedule page to view all sessions organized by day, track, and time. You can filter sessions by topic and add your favorites to "My Schedule" for easy reference. We recommend planning ahead as some popular sessions have limited capacity.',
  },
  {
    category: 'Speakers & Sessions',
    question: 'Can I meet the speakers?',
    answer: 'VIP ticket holders have exclusive access to speaker meet-and-greet events. All attendees can participate in Q&A sessions following each presentation. Speakers will also be present at networking events throughout the conference.',
  },
  {
    category: 'Speakers & Sessions',
    question: 'Will sessions be recorded?',
    answer: 'Yes, all keynote sessions and selected workshops will be recorded. Standard and VIP pass holders will have access to session recordings for 90 days after the conference. Access information will be provided in your post-event email.',
  },

  // Travel & Accommodation
  {
    category: 'Travel',
    question: 'How do I get to the venue?',
    answer: 'The Miami Beach Convention Center is easily accessible by car, taxi, Uber/Lyft, and public transportation. Miami International Airport (MIA) is approximately 15 minutes away. Complimentary shuttle service is available from select partner hotels. Detailed directions are available on our Venue page.',
  },
  {
    category: 'Travel',
    question: 'Is parking available?',
    answer: 'Yes, the convention center offers ample parking. Parking is complimentary for all registered attendees with validated tickets. Valet parking is available for VIP ticket holders. Electric vehicle charging stations are also available.',
  },
  {
    category: 'Travel',
    question: 'What hotels do you recommend?',
    answer: 'We have partnered with several hotels near the venue offering special rates for PARAISO attendees. Use promo code PARAISO2026 when booking. Recommended hotels include Fontainebleau Miami Beach, The Ritz-Carlton South Beach, and Loews Miami Beach Hotel. See our Venue page for the complete list.',
  },

  // Networking
  {
    category: 'Networking',
    question: 'What networking opportunities are available?',
    answer: 'PARAISO offers multiple networking opportunities including dedicated networking sessions, coffee breaks, lunch periods, evening receptions, and the Day 1 gala dinner. VIP attendees also have access to exclusive networking events and the VIP lounge.',
  },
  {
    category: 'Networking',
    question: 'Is there a conference app?',
    answer: 'Yes, we will provide a mobile app closer to the event date. The app includes the full schedule, interactive venue maps, attendee networking features, session reminders, and real-time updates. Download instructions will be sent to registered attendees.',
  },

  // Technical
  {
    category: 'Technical',
    question: 'Will WiFi be available?',
    answer: 'Yes, complimentary high-speed WiFi is available throughout the venue. Network credentials will be provided upon registration. The network name is PARAISO2026.',
  },
  {
    category: 'Technical',
    question: 'Can I charge my devices at the venue?',
    answer: 'Yes, charging stations are located throughout the venue. We also recommend bringing a portable charger. Power outlets are available in most seating areas.',
  },

  // Accessibility
  {
    category: 'Accessibility',
    question: 'Is the venue wheelchair accessible?',
    answer: 'Yes, the Miami Beach Convention Center is fully ADA compliant. All conference areas, restrooms, and facilities are wheelchair accessible. Elevators are available for multi-level access. Please contact us in advance if you need specific accommodations.',
  },
  {
    category: 'Accessibility',
    question: 'Can you accommodate dietary restrictions?',
    answer: 'Yes, we cater to various dietary requirements including vegetarian, vegan, gluten-free, halal, and kosher options. Please indicate your dietary preferences during registration so we can ensure appropriate meals are available.',
  },
];

export function FAQ() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', ...Array.from(new Set(faqs.map((f) => f.category)))];

  const filteredFAQs = faqs.filter((faq) => {
    const categoryMatch = selectedCategory === 'All' || faq.category === selectedCategory;
    const searchMatch =
      searchQuery === '' ||
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return categoryMatch && searchMatch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <section className="bg-gradient-to-br from-black via-gray-900 to-amber-900/20 py-20">
        <div className="container mx-auto px-4 text-center">
          <HelpCircle className="w-20 h-20 text-yellow-400 mx-auto mb-6" />
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent">
            Frequently Asked Questions
          </h1>
          <p className="text-xl text-white max-w-3xl mx-auto">
            Find answers to common questions about PARAISO 2026
          </p>
        </div>
      </section>

      {/* Search & Filter */}
      <section className="py-12 bg-white border-b border-gray-200">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search for answers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:bg-white text-lg"
              />
            </div>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                    selectedCategory === category
                      ? 'bg-gradient-to-r from-yellow-500 to-amber-600 text-black'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {filteredFAQs.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-xl text-gray-600">No FAQs found matching your search.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredFAQs.map((faq, index) => (
                  <div
                    key={index}
                    className="bg-white rounded-lg shadow-md border-2 border-gray-200 hover:border-yellow-400 transition-all overflow-hidden"
                  >
                    <button
                      onClick={() => setExpandedIndex(expandedIndex === index ? null : index)}
                      className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-gray-50 transition-all"
                    >
                      <div className="flex-1 pr-4">
                        <div className="text-sm font-semibold text-yellow-600 mb-1">
                          {faq.category}
                        </div>
                        <div className="text-lg font-bold text-black">{faq.question}</div>
                      </div>
                      {expandedIndex === index ? (
                        <ChevronUp className="w-6 h-6 text-yellow-600 flex-shrink-0" />
                      ) : (
                        <ChevronDown className="w-6 h-6 text-gray-400 flex-shrink-0" />
                      )}
                    </button>
                    {expandedIndex === index && (
                      <div className="px-6 pb-5 pt-2 border-t border-gray-200 bg-gray-50">
                        <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Still Have Questions */}
      <section className="py-20 bg-gradient-to-br from-yellow-500 via-amber-600 to-yellow-500">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-4xl font-bold mb-6 text-black">Still Have Questions?</h2>
            <p className="text-xl text-black/80 mb-8">
              Our team is here to help! Reach out to us and we'll get back to you as soon as possible.
            </p>
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white/20 backdrop-blur-sm p-6 rounded-lg border-2 border-black/30">
                <h3 className="font-bold text-black mb-2">Email</h3>
                <p className="text-black/80">info@paraiso.com</p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm p-6 rounded-lg border-2 border-black/30">
                <h3 className="font-bold text-black mb-2">Phone</h3>
                <p className="text-black/80">+1 (555) 123-4567</p>
              </div>
              <div className="bg-white/20 backdrop-blur-sm p-6 rounded-lg border-2 border-black/30">
                <h3 className="font-bold text-black mb-2">Hours</h3>
                <p className="text-black/80">Mon-Fri, 9AM-6PM EST</p>
              </div>
            </div>
            <a
              href="mailto:info@paraiso.com"
              className="inline-block px-8 py-4 bg-black text-yellow-400 font-bold text-lg rounded-lg hover:bg-gray-900 transition-all shadow-lg"
            >
              Contact Support
            </a>
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-white text-center">Helpful Resources</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {[
              { title: 'Registration Guide', description: 'Step-by-step registration process', link: '/registration' },
              { title: 'Schedule', description: 'Browse all sessions and tracks', link: '/schedule' },
              { title: 'Venue Information', description: 'Directions and parking details', link: '/venue' },
              { title: 'Speakers', description: 'Meet our expert speakers', link: '/speakers' },
            ].map((item, index) => (
              <a
                key={index}
                href={item.link}
                className="bg-white/10 backdrop-blur-sm p-6 rounded-lg border border-yellow-500/30 hover:border-yellow-500 transition-all group"
              >
                <h3 className="text-xl font-bold text-yellow-400 mb-2 group-hover:text-yellow-300">
                  {item.title}
                </h3>
                <p className="text-gray-300">{item.description}</p>
              </a>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
