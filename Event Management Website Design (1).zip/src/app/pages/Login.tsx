import { useState } from 'react';
import { Link, useNavigate } from 'react-router';

export function Login() {
  const navigate = useNavigate();
  const [isRightPanelActive, setIsRightPanelActive] = useState(false);
  const [signUpData, setSignUpData] = useState({ name: '', email: '', password: '' });
  const [signInData, setSignInData] = useState({ email: '', password: '' });
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error'>('success');
  const [showPasswordGuidelines, setShowPasswordGuidelines] = useState(false);

  // Password validation
  const validatePassword = (password: string) => {
    const minLength = password.length >= 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return {
      minLength,
      hasUpperCase,
      hasLowerCase,
      hasNumber,
      hasSpecialChar,
      isValid: minLength && hasUpperCase && hasLowerCase && hasNumber && hasSpecialChar
    };
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');

    // Validate password
    const passwordValidation = validatePassword(signUpData.password);
    if (!passwordValidation.isValid) {
      setMessageType('error');
      setMessage('Password does not meet all requirements. Please check the guidelines.');
      return;
    }

    // Store user data in localStorage (simulating backend)
    const users = JSON.parse(localStorage.getItem('paraiso_users') || '[]');
    
    // Check if email already exists
    if (users.some((user: any) => user.email === signUpData.email)) {
      setMessageType('error');
      setMessage('Email already registered. Please sign in.');
      return;
    }

    // Add new user
    const newUser = {
      id: Date.now().toString(),
      name: signUpData.name,
      email: signUpData.email,
      password: signUpData.password,
      isNewUser: true,
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    localStorage.setItem('paraiso_users', JSON.stringify(users));

    setMessageType('success');
    setMessage('Account created successfully! You can now sign in.');
    setSignUpData({ name: '', email: '', password: '' });
    setTimeout(() => setIsRightPanelActive(false), 1500);
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');

    const users = JSON.parse(localStorage.getItem('paraiso_users') || '[]');
    const user = users.find((u: any) => u.email === signInData.email && u.password === signInData.password);

    if (user) {
      setMessageType('success');
      setMessage('Login successful! Redirecting...');
      localStorage.setItem('paraiso_user', user.name);
      localStorage.setItem('paraiso_user_id', user.id);
      localStorage.setItem('paraiso_user_email', user.email);
      
      setTimeout(() => {
        const params = new URLSearchParams(window.location.search);
        const from = params.get('from') || '/';
        navigate(from);
      }, 1500);
    } else {
      setMessageType('error');
      setMessage('Invalid email or password.');
    }
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setMessage('');

    const users = JSON.parse(localStorage.getItem('paraiso_users') || '[]');
    const user = users.find((u: any) => u.email === forgotPasswordEmail);

    if (user) {
      setMessageType('success');
      setMessage(`Password reset link sent to ${forgotPasswordEmail}. Your password is: ${user.password}`);
      setForgotPasswordEmail('');
      setTimeout(() => setShowForgotPassword(false), 3000);
    } else {
      setMessageType('error');
      setMessage('Email not found. Please check and try again.');
    }
  };

  const passwordValidation = validatePassword(signUpData.password);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-yellow-900/20 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 text-9xl opacity-10 rotate-12">🌸</div>
      <div className="absolute top-0 right-0 text-9xl opacity-10 -rotate-12">🌺</div>
      <div className="absolute bottom-0 left-0 text-9xl opacity-10 -rotate-12">🌹</div>
      <div className="absolute bottom-0 right-0 text-9xl opacity-10 rotate-12">🌸</div>

      {/* Home Button */}
      <Link
        to="/"
        className="absolute top-4 left-4 px-6 py-3 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold rounded-full hover:from-yellow-400 hover:to-amber-500 transition-all shadow-lg z-50 flex items-center space-x-2"
      >
        <span>🏠</span>
        <span>Home</span>
      </Link>

      {/* Message */}
      {message && (
        <div
          className={`fixed top-8 left-1/2 transform -translate-x-1/2 z-50 px-6 py-3 rounded-lg font-bold shadow-xl ${
            messageType === 'success'
              ? 'bg-green-100 text-green-800 border-2 border-green-300'
              : 'bg-red-100 text-red-800 border-2 border-red-300'
          }`}
        >
          {message}
        </div>
      )}

      {/* Forgot Password Modal */}
      {showForgotPassword && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl">
            <h2 className="text-2xl font-bold text-black mb-4">Reset Password</h2>
            <p className="text-gray-600 mb-6">Enter your email address and we'll send you a password reset link.</p>
            <form onSubmit={handleForgotPassword}>
              <input
                type="email"
                placeholder="Email"
                value={forgotPasswordEmail}
                onChange={(e) => setForgotPasswordEmail(e.target.value)}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <div className="flex space-x-3">
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold rounded-lg hover:from-yellow-400 hover:to-amber-500 transition-all"
                >
                  Send Reset Link
                </button>
                <button
                  type="button"
                  onClick={() => setShowForgotPassword(false)}
                  className="flex-1 px-4 py-3 bg-gray-200 text-gray-700 font-bold rounded-lg hover:bg-gray-300 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Main Container */}
      <div className={`bg-white rounded-2xl shadow-2xl overflow-hidden max-w-4xl w-full relative transition-all duration-700 ${isRightPanelActive ? 'h-auto' : 'h-auto'}`}>
        <div className="grid md:grid-cols-2 min-h-[500px]">
          
          {/* Sign In Form */}
          <div className={`p-8 md:p-12 flex flex-col justify-center transition-all duration-700 ${isRightPanelActive ? 'md:order-2' : 'md:order-1'}`}>
            <h2 className="text-3xl font-bold text-black mb-6">Sign In</h2>
            <div className="flex space-x-3 mb-6">
              <a href="https://www.facebook.com/profile.php?id=61588248330824" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full border-2 border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-all">
                <span className="text-xl">f</span>
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full border-2 border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-all font-bold">
                YT
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full border-2 border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-all font-bold">
                IG
              </a>
            </div>
            <p className="text-sm text-gray-600 mb-4">or use your account</p>
            <form onSubmit={handleSignIn} className="space-y-4">
              <input
                type="email"
                placeholder="Email"
                value={signInData.email}
                onChange={(e) => setSignInData({ ...signInData, email: e.target.value })}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <input
                type="password"
                placeholder="Password"
                value={signInData.password}
                onChange={(e) => setSignInData({ ...signInData, password: e.target.value })}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <button
                type="button"
                onClick={() => setShowForgotPassword(true)}
                className="text-sm text-gray-600 hover:text-yellow-600 transition-colors"
              >
                Forgot your password?
              </button>
              <button
                type="submit"
                className="w-full px-6 py-3 bg-gradient-to-r from-yellow-400 to-amber-500 text-black font-bold rounded-lg hover:from-yellow-500 hover:to-amber-600 transition-all shadow-lg"
              >
                Sign In
              </button>
            </form>
            <div className="md:hidden mt-6 text-center">
              <p className="text-sm text-gray-600 mb-2">Don't have an account?</p>
              <button
                onClick={() => setIsRightPanelActive(true)}
                className="px-6 py-2 border-2 border-yellow-500 text-yellow-600 font-bold rounded-lg hover:bg-yellow-50 transition-all"
              >
                Sign Up
              </button>
            </div>
          </div>

          {/* Sign Up Form */}
          <div className={`p-8 md:p-12 flex flex-col justify-center bg-gray-50 transition-all duration-700 ${isRightPanelActive ? 'md:order-1' : 'md:order-2 hidden md:flex'}`}>
            <h2 className="text-3xl font-bold text-black mb-6">Create Account</h2>
            <div className="flex space-x-3 mb-6">
              <a href="https://www.facebook.com/profile.php?id=61588248330824" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full border-2 border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-all">
                <span className="text-xl">f</span>
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full border-2 border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-all font-bold">
                YT
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="w-12 h-12 rounded-full border-2 border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-all font-bold">
                IG
              </a>
            </div>
            <p className="text-sm text-gray-600 mb-4">or use your email for registration</p>
            <form onSubmit={handleSignUp} className="space-y-4">
              <input
                type="text"
                placeholder="Name"
                value={signUpData.name}
                onChange={(e) => setSignUpData({ ...signUpData, name: e.target.value })}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <input
                type="email"
                placeholder="Email"
                value={signUpData.email}
                onChange={(e) => setSignUpData({ ...signUpData, email: e.target.value })}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <div className="relative">
                <input
                  type="password"
                  placeholder="Password"
                  value={signUpData.password}
                  onChange={(e) => setSignUpData({ ...signUpData, password: e.target.value })}
                  onFocus={() => setShowPasswordGuidelines(true)}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
                />
                {showPasswordGuidelines && (
                  <div className="absolute z-10 mt-2 p-4 bg-white border-2 border-yellow-400 rounded-lg shadow-xl w-full">
                    <p className="font-bold text-sm mb-2">Password Requirements:</p>
                    <div className="space-y-1 text-xs">
                      <div className={passwordValidation.minLength ? 'text-green-600' : 'text-red-600'}>
                        {passwordValidation.minLength ? '✓' : '✗'} At least 8 characters
                      </div>
                      <div className={passwordValidation.hasUpperCase ? 'text-green-600' : 'text-red-600'}>
                        {passwordValidation.hasUpperCase ? '✓' : '✗'} At least one uppercase letter
                      </div>
                      <div className={passwordValidation.hasLowerCase ? 'text-green-600' : 'text-red-600'}>
                        {passwordValidation.hasLowerCase ? '✓' : '✗'} At least one lowercase letter
                      </div>
                      <div className={passwordValidation.hasNumber ? 'text-green-600' : 'text-red-600'}>
                        {passwordValidation.hasNumber ? '✓' : '✗'} At least one number
                      </div>
                      <div className={passwordValidation.hasSpecialChar ? 'text-green-600' : 'text-red-600'}>
                        {passwordValidation.hasSpecialChar ? '✓' : '✗'} At least one special character (!@#$%^&*)
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <button
                type="submit"
                className="w-full px-6 py-3 bg-gradient-to-r from-yellow-400 to-amber-500 text-black font-bold rounded-lg hover:from-yellow-500 hover:to-amber-600 transition-all shadow-lg"
              >
                Sign Up
              </button>
            </form>
            <div className="md:hidden mt-6 text-center">
              <p className="text-sm text-gray-600 mb-2">Already have an account?</p>
              <button
                onClick={() => setIsRightPanelActive(false)}
                className="px-6 py-2 border-2 border-yellow-500 text-yellow-600 font-bold rounded-lg hover:bg-yellow-50 transition-all"
              >
                Sign In
              </button>
            </div>
          </div>

        </div>

        {/* Desktop Toggle Overlay */}
        <div className={`hidden md:block absolute top-0 w-1/2 h-full bg-gradient-to-r from-yellow-400 to-amber-500 transition-all duration-700 ${isRightPanelActive ? 'left-0' : 'left-1/2'}`}>
          <div className="flex flex-col items-center justify-center h-full text-center p-12 text-black">
            {!isRightPanelActive ? (
              <>
                <h2 className="text-3xl font-bold mb-4">Hello, Friend!</h2>
                <p className="mb-6">Enter your personal details and start your journey with us</p>
                <button
                  onClick={() => setIsRightPanelActive(true)}
                  className="px-8 py-3 border-2 border-black bg-transparent text-black font-bold rounded-lg hover:bg-black/10 transition-all"
                >
                  Sign Up
                </button>
              </>
            ) : (
              <>
                <h2 className="text-3xl font-bold mb-4">Welcome Back!</h2>
                <p className="mb-6">To keep connected with us please login with your personal info</p>
                <button
                  onClick={() => setIsRightPanelActive(false)}
                  className="px-8 py-3 border-2 border-black bg-transparent text-black font-bold rounded-lg hover:bg-black/10 transition-all"
                >
                  Sign In
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
