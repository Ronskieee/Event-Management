import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { Check, Users, Star, Crown, AlertCircle, X } from 'lucide-react';
import { useTheme } from '../components/ThemeContext';

interface TicketType {
  id: string;
  name: string;
  price: number;
  icon: typeof Users;
  features: string[];
  available: boolean;
  badge?: string;
  color: string;
}

const ticketTypes: TicketType[] = [
  {
    id: 'early-bird',
    name: 'Early Bird',
    price: 499,
    icon: Users,
    features: [
      'Access to all sessions',
      'Conference materials',
      'Networking events',
      'Lunch & refreshments',
      'Certificate of attendance',
    ],
    available: true,
    badge: 'Save ₱200',
    color: 'from-green-500 to-emerald-600',
  },
  {
    id: 'standard',
    name: 'Standard Pass',
    price: 699,
    icon: Star,
    features: [
      'Access to all sessions',
      'Conference materials',
      'Networking events',
      'Lunch & refreshments',
      'Certificate of attendance',
      'Access to recordings',
    ],
    available: true,
    color: 'from-blue-500 to-indigo-600',
  },
  {
    id: 'vip',
    name: 'VIP Experience',
    price: 1299,
    icon: Crown,
    features: [
      'Everything in Standard',
      'VIP lounge access',
      'Priority seating',
      'Exclusive speaker meet & greet',
      'Premium conference swag',
      'Gala dinner invitation',
      'One-on-one mentoring session',
      '1 year premium content access',
    ],
    available: true,
    badge: 'Most Popular',
    color: 'from-yellow-500 to-amber-600',
  },
];

export function Registration() {
  const { darkMode } = useTheme();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // Get URL params
  const urlEventType = searchParams.get('eventType');
  const urlVenue = searchParams.get('venue');
  const urlDate = searchParams.get('date');
  const urlPackage = searchParams.get('package');

  const [selectedTicket, setSelectedTicket] = useState<string>('vip');
  const [quantity, setQuantity] = useState<number>(1);
  const [promoCode, setPromoCode] = useState<string>('');
  const [promoMessage, setPromoMessage] = useState<string>('');
  const [discount, setDiscount] = useState<number>(0);
  const [promoUsed, setPromoUsed] = useState<string[]>([]);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: '',
    jobTitle: '',
    dietaryPreferences: '',
    specialRequests: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  // Load used promo codes from user
  useEffect(() => {
    const userId = localStorage.getItem('paraiso_user_id');
    if (userId) {
      const usedCodes = JSON.parse(localStorage.getItem(`paraiso_promo_used_${userId}`) || '[]');
      setPromoUsed(usedCodes);
    }
  }, []);

  const selectedTicketData = ticketTypes.find((t) => t.id === selectedTicket);
  const subtotal = selectedTicketData ? selectedTicketData.price * quantity : 0;
  const discountAmount = subtotal * (discount / 100);
  const total = subtotal - discountAmount;

  const applyPromoCode = () => {
    const code = promoCode.toUpperCase();
    const userId = localStorage.getItem('paraiso_user_id');
    
    if (!userId) {
      setPromoMessage('Please login to use promo codes');
      setDiscount(0);
      return;
    }

    // Check if promo already used
    if (promoUsed.includes(code)) {
      setPromoMessage('You have already used this promo code');
      setDiscount(0);
      return;
    }

    // VIPCODE - only for VIP tickets
    if (code === 'VIPCODE') {
      if (selectedTicket === 'vip') {
        setDiscount(10);
        setPromoMessage('VIP code applied! 10% off');
      } else {
        setPromoMessage('This code is only valid for VIP tickets');
        setDiscount(0);
      }
      return;
    }

    // EARLYBIRD - only within 1 week of earliest available date
    if (code === 'EARLYBIRD') {
      if (urlDate) {
        const bookingDate = new Date(urlDate);
        const earliestDate = new Date();
        earliestDate.setDate(earliestDate.getDate() + 14); // minimum 2 weeks
        const oneWeekAfter = new Date(earliestDate);
        oneWeekAfter.setDate(oneWeekAfter.getDate() + 7);

        if (bookingDate >= earliestDate && bookingDate <= oneWeekAfter) {
          setDiscount(15);
          setPromoMessage('Early bird discount applied! 15% off');
        } else {
          setPromoMessage('This code is only valid for bookings within 1 week of the earliest available date');
          setDiscount(0);
        }
      } else {
        setPromoMessage('Please select a date first');
        setDiscount(0);
      }
      return;
    }

    // PARAISO20 - only for new users
    if (code === 'PARAISO20') {
      const users = JSON.parse(localStorage.getItem('paraiso_users') || '[]');
      const user = users.find((u: any) => u.id === userId);
      
      if (user && user.isNewUser) {
        setDiscount(20);
        setPromoMessage('New user discount applied! 20% off');
      } else {
        setPromoMessage('This code is only valid for new users');
        setDiscount(0);
      }
      return;
    }

    setPromoMessage('Invalid promo code');
    setDiscount(0);
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    const userId = localStorage.getItem('paraiso_user_id');

    if (!userId) {
      alert('Please login to complete your booking');
      navigate('/login?from=/registration');
      return false;
    }

    if (!formData.firstName.trim()) {
      newErrors.firstName = 'First name is required';
    }
    if (!formData.lastName.trim()) {
      newErrors.lastName = 'Last name is required';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    if (!formData.company.trim()) {
      newErrors.company = 'Company name is required';
    }

    // Validate booking - check for double booking
    if (urlDate && urlVenue) {
      const allBookings = JSON.parse(localStorage.getItem('paraiso_bookings') || '[]');
      const doubleBooking = allBookings.find(
        (b: any) => b.date === urlDate && b.venue === urlVenue && !b.id.startsWith(userId)
      );

      if (doubleBooking) {
        alert(`Sorry, ${urlVenue} is already booked for ${urlDate}. Please select another date or venue.`);
        return false;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      const userId = localStorage.getItem('paraiso_user_id');
      const userName = localStorage.getItem('paraiso_user');
      
      // Create booking
      const booking = {
        id: `${userId}_${Date.now()}`,
        eventType: urlEventType || 'Conference',
        venue: urlVenue || 'TBD',
        date: urlDate || '',
        package: urlPackage || selectedTicketData?.name || '',
        price: total,
        ticketType: selectedTicketData?.name || '',
        quantity,
        userName: userName || formData.firstName + ' ' + formData.lastName,
        userEmail: formData.email,
        timestamp: new Date().toISOString(),
        ...formData
      };

      // Save booking
      const allBookings = JSON.parse(localStorage.getItem('paraiso_bookings') || '[]');
      allBookings.push(booking);
      localStorage.setItem('paraiso_bookings', JSON.stringify(allBookings));

      // Save event date and details to localStorage for countdown
      if (urlDate) {
        localStorage.setItem('paraiso_event_date', urlDate);
      }
      if (urlEventType) {
        localStorage.setItem('paraiso_event_type', urlEventType);
      }
      if (urlVenue) {
        localStorage.setItem('paraiso_venue', urlVenue);
      }

      // Mark promo as used
      if (discount > 0 && promoCode) {
        const code = promoCode.toUpperCase();
        const usedCodes = [...promoUsed, code];
        localStorage.setItem(`paraiso_promo_used_${userId}`, JSON.stringify(usedCodes));
      }

      // Mark user as no longer new
      if (promoCode.toUpperCase() === 'PARAISO20') {
        const users = JSON.parse(localStorage.getItem('paraiso_users') || '[]');
        const userIndex = users.findIndex((u: any) => u.id === userId);
        if (userIndex !== -1) {
          users[userIndex].isNewUser = false;
          localStorage.setItem('paraiso_users', JSON.stringify(users));
        }
      }

      setBookingSuccess(true);
      setSubmitted(true);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  if (bookingSuccess) {
    return (
      <div className={`min-h-screen ${darkMode ? 'bg-gray-950' : 'bg-gradient-to-br from-yellow-500 via-amber-600 to-yellow-500'} flex items-center justify-center p-4`}>
        <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-2xl p-12 max-w-2xl text-center`}>
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-12 h-12 text-green-600" />
          </div>
          <h1 className={`text-4xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-black'}`}>Booking Successful!</h1>
          <p className={`text-xl mb-6 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
            Thank you for your booking, {formData.firstName}!
          </p>
          <div className={`${darkMode ? 'bg-yellow-900/20 border-yellow-600/30' : 'bg-yellow-50 border-yellow-300'} border-2 rounded-lg p-6 mb-8`}>
            <h2 className={`text-2xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-black'}`}>Booking Summary</h2>
            <div className="space-y-2 text-left">
              {urlEventType && (
                <div className="flex justify-between">
                  <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>Event Type:</span>
                  <span className={`font-semibold ${darkMode ? 'text-white' : 'text-black'}`}>{urlEventType}</span>
                </div>
              )}
              {urlVenue && (
                <div className="flex justify-between">
                  <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>Venue:</span>
                  <span className={`font-semibold ${darkMode ? 'text-white' : 'text-black'}`}>{urlVenue}</span>
                </div>
              )}
              {urlDate && (
                <div className="flex justify-between">
                  <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>Date:</span>
                  <span className={`font-semibold ${darkMode ? 'text-white' : 'text-black'}`}>
                    {new Date(urlDate).toLocaleDateString('en-PH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                  </span>
                </div>
              )}
              {urlPackage && (
                <div className="flex justify-between">
                  <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>Package:</span>
                  <span className={`font-semibold ${darkMode ? 'text-white' : 'text-black'}`}>{urlPackage}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>Ticket Type:</span>
                <span className={`font-semibold ${darkMode ? 'text-white' : 'text-black'}`}>{selectedTicketData?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>Quantity:</span>
                <span className={`font-semibold ${darkMode ? 'text-white' : 'text-black'}`}>{quantity}</span>
              </div>
              <div className="flex justify-between border-t pt-2 mt-2">
                <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>Total:</span>
                <span className={`font-semibold text-xl ${darkMode ? 'text-yellow-400' : 'text-black'}`}>₱{total.toFixed(2)}</span>
              </div>
            </div>
          </div>
          <p className={`mb-8 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            A confirmation email has been sent to <span className="font-semibold">{formData.email}</span>.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => navigate('/bookings')}
              className="px-8 py-4 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold text-lg rounded-lg hover:from-yellow-400 hover:to-amber-500 transition-all"
            >
              View My Bookings
            </button>
            <button
              onClick={() => navigate('/')}
              className={`px-8 py-4 ${darkMode ? 'bg-gray-700 text-white hover:bg-gray-600' : 'bg-gray-200 text-black hover:bg-gray-300'} font-bold text-lg rounded-lg transition-all`}
            >
              Return to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      {/* Hero */}
      <section className={`py-20 ${darkMode ? 'bg-gradient-to-br from-gray-900 via-black to-amber-900/10' : 'bg-gradient-to-br from-black via-gray-900 to-amber-900/20'}`}>
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent">
            Complete Your Booking
          </h1>
          {urlEventType && urlVenue && urlDate && (
            <div className="max-w-2xl mx-auto bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-yellow-400/30">
              <p className="text-yellow-400 text-lg font-bold mb-2">Your Selection:</p>
              <div className="text-white space-y-1">
                <p>📍 <strong>{urlEventType}</strong> at <strong>{urlVenue}</strong></p>
                <p>📅 {new Date(urlDate).toLocaleDateString('en-PH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                {urlPackage && <p>📦 Package: <strong>{urlPackage}</strong></p>}
              </div>
            </div>
          )}
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Ticket Selection */}
          <div className="lg:col-span-3">
            <h2 className={`text-3xl font-bold mb-8 ${darkMode ? 'text-white' : 'text-black'}`}>Select Your Ticket</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {ticketTypes.map((ticket) => {
                const Icon = ticket.icon;
                return (
                  <div
                    key={ticket.id}
                    onClick={() => ticket.available && setSelectedTicket(ticket.id)}
                    className={`relative ${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg overflow-hidden cursor-pointer transition-all ${
                      selectedTicket === ticket.id
                        ? 'ring-4 ring-yellow-400 transform scale-105'
                        : 'hover:shadow-xl'
                    } ${!ticket.available && 'opacity-50 cursor-not-allowed'}`}
                  >
                    {ticket.badge && (
                      <div className={`absolute top-4 right-4 px-3 py-1 bg-gradient-to-r ${ticket.color} text-white text-sm font-semibold rounded-full`}>
                        {ticket.badge}
                      </div>
                    )}
                    <div className={`bg-gradient-to-r ${ticket.color} p-6 text-white`}>
                      <Icon className="w-12 h-12 mb-4" />
                      <h3 className="text-2xl font-bold mb-2">{ticket.name}</h3>
                      <div className="text-4xl font-bold">₱{ticket.price}</div>
                      <div className="text-sm opacity-90">per person</div>
                    </div>
                    <div className="p-6">
                      <ul className="space-y-3">
                        {ticket.features.map((feature, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                            <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    {selectedTicket === ticket.id && (
                      <div className="absolute inset-0 border-4 border-yellow-400 rounded-lg pointer-events-none"></div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Registration Form */}
          <div className="lg:col-span-2">
            <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-8`}>
              <h2 className={`text-3xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-black'}`}>Registration Details</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      First Name *
                    </label>
                    <input
                      type="text"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                        errors.firstName
                          ? 'border-red-500 focus:ring-red-500'
                          : darkMode
                          ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                          : 'border-gray-300 focus:ring-yellow-500'
                      }`}
                    />
                    {errors.firstName && (
                      <p className="text-red-500 text-sm mt-1 flex items-center space-x-1">
                        <AlertCircle className="w-4 h-4" />
                        <span>{errors.firstName}</span>
                      </p>
                    )}
                  </div>
                  <div>
                    <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      Last Name *
                    </label>
                    <input
                      type="text"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                        errors.lastName
                          ? 'border-red-500 focus:ring-red-500'
                          : darkMode
                          ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                          : 'border-gray-300 focus:ring-yellow-500'
                      }`}
                    />
                    {errors.lastName && (
                      <p className="text-red-500 text-sm mt-1 flex items-center space-x-1">
                        <AlertCircle className="w-4 h-4" />
                        <span>{errors.lastName}</span>
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Email Address *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                      errors.email
                        ? 'border-red-500 focus:ring-red-500'
                        : darkMode
                        ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                        : 'border-gray-300 focus:ring-yellow-500'
                    }`}
                  />
                  {errors.email && (
                    <p className="text-red-500 text-sm mt-1 flex items-center space-x-1">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.email}</span>
                    </p>
                  )}
                </div>

                <div>
                  <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                      errors.phone
                        ? 'border-red-500 focus:ring-red-500'
                        : darkMode
                        ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                        : 'border-gray-300 focus:ring-yellow-500'
                    }`}
                  />
                  {errors.phone && (
                    <p className="text-red-500 text-sm mt-1 flex items-center space-x-1">
                      <AlertCircle className="w-4 h-4" />
                      <span>{errors.phone}</span>
                    </p>
                  )}
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      Company *
                    </label>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                        errors.company
                          ? 'border-red-500 focus:ring-red-500'
                          : darkMode
                          ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                          : 'border-gray-300 focus:ring-yellow-500'
                      }`}
                    />
                    {errors.company && (
                      <p className="text-red-500 text-sm mt-1 flex items-center space-x-1">
                        <AlertCircle className="w-4 h-4" />
                        <span>{errors.company}</span>
                      </p>
                    )}
                  </div>
                  <div>
                    <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      Job Title
                    </label>
                    <input
                      type="text"
                      name="jobTitle"
                      value={formData.jobTitle}
                      onChange={handleInputChange}
                      className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                        darkMode
                          ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                          : 'border-gray-300 focus:ring-yellow-500'
                      }`}
                    />
                  </div>
                </div>

                <div>
                  <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Dietary Preferences
                  </label>
                  <select
                    name="dietaryPreferences"
                    value={formData.dietaryPreferences}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                      darkMode
                        ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                        : 'border-gray-300 focus:ring-yellow-500'
                    }`}
                  >
                    <option value="">Select preference</option>
                    <option value="none">No restrictions</option>
                    <option value="vegetarian">Vegetarian</option>
                    <option value="vegan">Vegan</option>
                    <option value="gluten-free">Gluten-free</option>
                    <option value="halal">Halal</option>
                    <option value="kosher">Kosher</option>
                    <option value="other">Other (specify in special requests)</option>
                  </select>
                </div>

                <div>
                  <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Special Requests or Accommodations
                  </label>
                  <textarea
                    name="specialRequests"
                    value={formData.specialRequests}
                    onChange={handleInputChange}
                    rows={4}
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                      darkMode
                        ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                        : 'border-gray-300 focus:ring-yellow-500'
                    }`}
                    placeholder="Any accessibility needs, allergies, or other special requirements..."
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-gradient-to-r from-yellow-500 to-amber-600 text-black font-bold text-lg rounded-lg hover:from-yellow-400 hover:to-amber-500 transition-all shadow-lg"
                >
                  Complete Booking
                </button>
              </form>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-lg shadow-lg p-8 sticky top-8`}>
              <h2 className={`text-2xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-black'}`}>Order Summary</h2>

              <div className="space-y-4 mb-6">
                <div>
                  <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Number of Tickets
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, Math.min(10, parseInt(e.target.value) || 1)))}
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                      darkMode
                        ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                        : 'border-gray-300 focus:ring-yellow-500'
                    }`}
                  />
                </div>

                <div>
                  <label className={`block text-sm font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                    Promo Code
                  </label>
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      placeholder="Enter code"
                      className={`flex-1 px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 ${
                        darkMode
                          ? 'bg-gray-700 border-gray-600 text-white focus:ring-yellow-500'
                          : 'border-gray-300 focus:ring-yellow-500'
                      }`}
                    />
                    <button
                      type="button"
                      onClick={applyPromoCode}
                      className={`px-4 py-3 ${darkMode ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-800 hover:bg-gray-700'} text-white rounded-lg transition-all`}
                    >
                      Apply
                    </button>
                  </div>
                  {promoMessage && (
                    <p className={`text-sm mt-2 ${discount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {promoMessage}
                    </p>
                  )}
                </div>
              </div>

              <div className={`border-t pt-6 space-y-3 ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
                <div className={`flex justify-between ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  <span>Ticket Type:</span>
                  <span className="font-semibold">{selectedTicketData?.name}</span>
                </div>
                <div className={`flex justify-between ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  <span>Price per ticket:</span>
                  <span className="font-semibold">₱{selectedTicketData?.price}</span>
                </div>
                <div className={`flex justify-between ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  <span>Quantity:</span>
                  <span className="font-semibold">{quantity}</span>
                </div>
                <div className={`flex justify-between ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  <span>Subtotal:</span>
                  <span className="font-semibold">₱{subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount ({discount}%):</span>
                    <span className="font-semibold">-₱{discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className={`border-t pt-3 flex justify-between text-xl font-bold ${darkMode ? 'border-gray-700 text-yellow-400' : 'border-gray-200 text-black'}`}>
                  <span>Total:</span>
                  <span>₱{total.toFixed(2)}</span>
                </div>
              </div>

              <div className={`mt-6 p-4 rounded-lg ${darkMode ? 'bg-yellow-900/20 border border-yellow-600/30' : 'bg-yellow-50 border border-yellow-200'}`}>
                <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  <strong>Available promo codes:</strong>
                  <br />• VIPCODE (10% off VIP tickets)
                  <br />• EARLYBIRD (15% off early bookings)
                  <br />• PARAISO20 (20% off for new users)
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
