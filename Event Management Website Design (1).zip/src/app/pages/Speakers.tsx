import { useState } from 'react';
import { Linkedin, Twitter, Globe, ChevronDown, ChevronUp, Search } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

interface Speaker {
  id: string;
  name: string;
  title: string;
  company: string;
  image: string;
  bio: string;
  expertise: string[];
  social: {
    linkedin?: string;
    twitter?: string;
    website?: string;
  };
}

const speakers: Speaker[] = [
  {
    id: '1',
    name: 'Dr. Sarah Chen',
    title: 'Chief Innovation Officer',
    company: 'TechVision Global',
    image: 'https://images.unsplash.com/photo-1764173039197-efc6c758b2c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHdvbWFuJTIwc3BlYWtlciUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NzE0MDg1NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'Dr. Sarah Chen is a visionary leader in technology innovation with over 20 years of experience driving digital transformation across Fortune 500 companies. She holds a Ph.D. in Computer Science from MIT and has been recognized by Forbes as one of the top 50 women in tech. Her groundbreaking work in AI ethics and human-centered design has influenced industry standards worldwide.',
    expertise: ['Innovation', 'AI & Machine Learning', 'Digital Transformation', 'Leadership'],
    social: {
      linkedin: '#',
      twitter: '#',
      website: '#',
    },
  },
  {
    id: '2',
    name: 'Michael Rodriguez',
    title: 'CEO & Founder',
    company: 'Innovate Labs',
    image: 'https://images.unsplash.com/photo-1621062089461-01f1eaebb66c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwYW1lcmljYW4lMjBidXNpbmVzc21hbiUyMGV4ZWN1dGl2ZXxlbnwxfHx8fDE3NzE0MDg1NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'Michael Rodriguez is a serial entrepreneur and thought leader in the startup ecosystem. He has successfully founded and exited three companies, with a combined valuation exceeding $500 million. As a sought-after speaker and advisor, Michael shares his insights on scaling businesses, leadership, and creating sustainable competitive advantages in dynamic markets.',
    expertise: ['Entrepreneurship', 'Business Strategy', 'Startups', 'Leadership'],
    social: {
      linkedin: '#',
      twitter: '#',
    },
  },
  {
    id: '3',
    name: 'Emily Thompson',
    title: 'VP of Marketing',
    company: 'BrandFirst Media',
    image: 'https://images.unsplash.com/photo-1581065178026-390bc4e78dad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMHdvbWFuJTIwcHJvZmVzc2lvbmFsJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzcxMzA4Njg3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'Emily Thompson is an award-winning marketing executive known for building iconic brands and driving exponential growth. With expertise spanning digital marketing, brand strategy, and customer experience, she has led successful campaigns for global brands. Emily is passionate about the intersection of creativity and data-driven decision making.',
    expertise: ['Marketing', 'Branding', 'Digital Strategy', 'Customer Experience'],
    social: {
      linkedin: '#',
      website: '#',
    },
  },
  {
    id: '4',
    name: 'James Wilson',
    title: 'Director of Sustainability',
    company: 'Green Future Corp',
    image: 'https://images.unsplash.com/photo-1740485863716-8e1851b6d474?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaXNwYW5pYyUyMG1hbiUyMGJ1c2luZXNzJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc3MTQwODU1N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'James Wilson is a leading voice in corporate sustainability and environmental responsibility. He has helped numerous Fortune 1000 companies develop and implement comprehensive ESG strategies. His work focuses on demonstrating that sustainability and profitability are not mutually exclusive but rather complementary forces driving business success.',
    expertise: ['Sustainability', 'ESG', 'Corporate Responsibility', 'Climate Action'],
    social: {
      linkedin: '#',
      twitter: '#',
      website: '#',
    },
  },
  {
    id: '5',
    name: 'Lisa Park',
    title: 'Head of Design',
    company: 'CreativeMinds Studio',
    image: 'https://images.unsplash.com/photo-1653671832574-029b950a5749?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB3b21hbiUyMHByb2Zlc3Npb25hbCUyMGhlYWRzaG90fGVufDF8fHx8MTc3MTMxMjk1OHww&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'Lisa Park is an internationally acclaimed design thinking expert and innovation facilitator. She has trained thousands of professionals in human-centered design methodologies and has led transformative projects for clients ranging from startups to multinational corporations. Lisa believes in the power of design to solve complex business and social challenges.',
    expertise: ['Design Thinking', 'Innovation', 'User Experience', 'Product Design'],
    social: {
      linkedin: '#',
      twitter: '#',
    },
  },
  {
    id: '6',
    name: 'David Kumar',
    title: 'Chief Data Officer',
    company: 'DataDriven Solutions',
    image: 'https://images.unsplash.com/photo-1758519289585-a31cf5b6defe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXVjYXNpYW4lMjBtYW4lMjBidXNpbmVzcyUyMHN1aXR8ZW58MXx8fHwxNzcxNDA4NTU4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'David Kumar is a data analytics pioneer who has revolutionized how organizations leverage data for strategic decision-making. With a background in mathematics and computer science, he has developed cutting-edge analytics frameworks used by leading companies worldwide. David is passionate about making data accessible and actionable for business leaders at all levels.',
    expertise: ['Data Analytics', 'Business Intelligence', 'Machine Learning', 'Strategy'],
    social: {
      linkedin: '#',
      website: '#',
    },
  },
  {
    id: '7',
    name: 'Jennifer Martinez',
    title: 'Customer Experience Director',
    company: 'Engage360',
    image: 'https://images.unsplash.com/photo-1764173039197-efc6c758b2c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHdvbWFuJTIwc3BlYWtlciUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NzE0MDg1NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'Jennifer Martinez is an expert in creating memorable customer experiences that drive loyalty and growth. She has spent 15 years optimizing customer journeys across multiple industries and has been instrumental in transforming how companies approach customer-centricity. Jennifer combines psychology, technology, and business acumen to deliver exceptional results.',
    expertise: ['Customer Experience', 'Journey Mapping', 'Service Design', 'Marketing'],
    social: {
      linkedin: '#',
      twitter: '#',
    },
  },
  {
    id: '8',
    name: 'Alex Zhang',
    title: 'Blockchain Strategist',
    company: 'CryptoVentures',
    image: 'https://images.unsplash.com/photo-1621062089461-01f1eaebb66c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZnJpY2FuJTIwYW1lcmljYW4lMjBidXNpbmVzc21hbiUyMGV4ZWN1dGl2ZXxlbnwxfHx8fDE3NzE0MDg1NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'Alex Zhang is at the forefront of blockchain technology and Web3 innovation. As an early adopter and advocate, he has helped organizations understand and implement blockchain solutions across various use cases. Alex provides clear, practical guidance on navigating the complex and rapidly evolving world of decentralized technologies and digital assets.',
    expertise: ['Blockchain', 'Web3', 'Cryptocurrency', 'Cybersecurity'],
    social: {
      linkedin: '#',
      twitter: '#',
      website: '#',
    },
  },
  {
    id: '9',
    name: 'Robert Anderson',
    title: 'CFO',
    company: 'Growth Capital Partners',
    image: 'https://images.unsplash.com/photo-1758519289585-a31cf5b6defe?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXVjYXNpYW4lMjBtYW4lMjBidXNpbmVzcyUyMHN1aXR8ZW58MXx8fHwxNzcxNDA4NTU4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'Robert Anderson brings over 25 years of financial leadership experience, having served as CFO for multiple high-growth companies. He specializes in financial strategy, capital allocation, and scaling operations. Robert is known for his ability to translate complex financial concepts into actionable insights that drive business performance and shareholder value.',
    expertise: ['Finance', 'Strategy', 'Investment', 'Operations'],
    social: {
      linkedin: '#',
      website: '#',
    },
  },
  {
    id: '10',
    name: 'Patricia Lee',
    title: 'Talent Development VP',
    company: 'PeopleFirst Consulting',
    image: 'https://images.unsplash.com/photo-1581065178026-390bc4e78dad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2lhbiUyMHdvbWFuJTIwcHJvZmVzc2lvbmFsJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzcxMzA4Njg3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    bio: 'Patricia Lee is a renowned expert in talent development and organizational psychology. She has designed and implemented award-winning learning programs for global organizations, focusing on leadership development, employee engagement, and building high-performance cultures. Patricia is passionate about unlocking human potential and creating workplaces where people thrive.',
    expertise: ['HR', 'Leadership Development', 'Team Building', 'Culture'],
    social: {
      linkedin: '#',
      twitter: '#',
    },
  },
];

export function Speakers() {
  const [expandedSpeaker, setExpandedSpeaker] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSpeakers = speakers.filter((speaker) => {
    if (searchQuery === '') return true;
    const query = searchQuery.toLowerCase();
    return (
      speaker.name.toLowerCase().includes(query) ||
      speaker.title.toLowerCase().includes(query) ||
      speaker.company.toLowerCase().includes(query) ||
      speaker.expertise.some((exp) => exp.toLowerCase().includes(query)) ||
      speaker.bio.toLowerCase().includes(query)
    );
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero */}
      <section className="bg-gradient-to-br from-black via-gray-900 to-amber-900/20 py-20">
        <div className="container mx-auto px-4">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent text-center">
            Our Speakers
          </h1>
          <p className="text-xl text-white text-center mb-8 max-w-3xl mx-auto">
            Learn from industry pioneers, thought leaders, and visionaries shaping the future
          </p>

          {/* Search */}
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search speakers by name, expertise, or company..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-white border border-gray-300 rounded-lg focus:outline-none focus:border-yellow-500"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Speakers Grid */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredSpeakers.map((speaker) => (
              <div
                key={speaker.id}
                className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-all"
              >
                {/* Speaker Image */}
                <div className="relative h-80 overflow-hidden group">
                  <ImageWithFallback
                    src={speaker.image}
                    alt={speaker.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3 className="text-2xl font-bold text-white mb-1">{speaker.name}</h3>
                    <p className="text-yellow-400 font-semibold">{speaker.title}</p>
                    <p className="text-white/90">{speaker.company}</p>
                  </div>
                </div>

                {/* Speaker Info */}
                <div className="p-6">
                  {/* Expertise Tags */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {speaker.expertise.map((exp, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-yellow-100 text-yellow-800 text-xs font-semibold rounded-full"
                      >
                        {exp}
                      </span>
                    ))}
                  </div>

                  {/* Bio */}
                  <div className="mb-4">
                    <p className={`text-gray-600 ${expandedSpeaker === speaker.id ? '' : 'line-clamp-3'}`}>
                      {speaker.bio}
                    </p>
                    <button
                      onClick={() =>
                        setExpandedSpeaker(expandedSpeaker === speaker.id ? null : speaker.id)
                      }
                      className="text-yellow-600 font-semibold mt-2 flex items-center space-x-1 hover:text-yellow-700"
                    >
                      <span>{expandedSpeaker === speaker.id ? 'Show less' : 'Read more'}</span>
                      {expandedSpeaker === speaker.id ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  {/* Social Links */}
                  <div className="flex items-center space-x-3 pt-4 border-t border-gray-200">
                    {speaker.social.linkedin && (
                      <a
                        href={speaker.social.linkedin}
                        className="p-2 bg-gray-100 hover:bg-yellow-100 rounded-lg transition-all"
                        title="LinkedIn"
                      >
                        <Linkedin className="w-5 h-5 text-gray-700" />
                      </a>
                    )}
                    {speaker.social.twitter && (
                      <a
                        href={speaker.social.twitter}
                        className="p-2 bg-gray-100 hover:bg-yellow-100 rounded-lg transition-all"
                        title="Twitter"
                      >
                        <Twitter className="w-5 h-5 text-gray-700" />
                      </a>
                    )}
                    {speaker.social.website && (
                      <a
                        href={speaker.social.website}
                        className="p-2 bg-gray-100 hover:bg-yellow-100 rounded-lg transition-all"
                        title="Website"
                      >
                        <Globe className="w-5 h-5 text-gray-700" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredSpeakers.length === 0 && (
            <div className="text-center py-12">
              <p className="text-xl text-gray-600">No speakers found matching your search.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-yellow-500 via-amber-600 to-yellow-500">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-5xl font-bold mb-6 text-black">Want to Meet Our Speakers?</h2>
          <p className="text-xl mb-8 text-black/80 max-w-2xl mx-auto">
            Register now to attend their sessions, participate in Q&A, and network during exclusive speaker events.
          </p>
          <a
            href="/registration"
            className="inline-block px-8 py-4 bg-black text-yellow-400 font-bold text-lg rounded-lg hover:bg-gray-900 transition-all shadow-lg"
          >
            Register for PARAISO 2026
          </a>
        </div>
      </section>
    </div>
  );
}
