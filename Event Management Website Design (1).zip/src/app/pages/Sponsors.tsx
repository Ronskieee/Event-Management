import { Mail, Phone, FileText } from 'lucide-react';
import { useTheme } from '../components/ThemeContext';

interface Sponsor {
  name: string;
  tier: 'platinum' | 'gold' | 'silver';
  logo: string;
  description: string;
}

const sponsors: Sponsor[] = [
  // Platinum
  { name: 'Grand Ballroom Hall', tier: 'platinum', logo: 'GB', description: 'Premier event space with luxury amenities' },
  { name: 'Diamond Conference Center', tier: 'platinum', logo: 'DC', description: 'State-of-the-art meeting facility' },
  { name: 'Royal Summit Pavilion', tier: 'platinum', logo: 'RS', description: 'Elite corporate event venue' },

  // Gold
  { name: 'Metropolitan Plaza', tier: 'gold', logo: 'MP', description: 'Modern downtown venue' },
  { name: 'Skyline Convention Hall', tier: 'gold', logo: 'SC', description: 'High-rise event space' },
  { name: 'Harbor View Center', tier: 'gold', logo: 'HV', description: 'Waterfront meeting venue' },
  { name: 'Capitol Events Complex', tier: 'gold', logo: 'CE', description: 'Historic landmark venue' },
  { name: 'Crystal Garden Arena', tier: 'gold', logo: 'CG', description: 'Elegant botanical venue' },

  // Silver
  { name: 'Riverside Conference Room', tier: 'silver', logo: 'RC', description: 'Boutique meeting space' },
  { name: 'Summit Peak Lodge', tier: 'silver', logo: 'SP', description: 'Mountain retreat venue' },
  { name: 'Marina Bay Hall', tier: 'silver', logo: 'MB', description: 'Coastal event facility' },
  { name: 'Heritage Gallery Venue', tier: 'silver', logo: 'HG', description: 'Cultural event space' },
  { name: 'Innovation Hub Center', tier: 'silver', logo: 'IH', description: 'Tech-focused venue' },
  { name: 'Garden Terrace Hall', tier: 'silver', logo: 'GT', description: 'Outdoor event space' },
  { name: 'Aurora Meeting Rooms', tier: 'silver', logo: 'AM', description: 'Flexible conference venue' },
  { name: 'Prestige Tower Suites', tier: 'silver', logo: 'PT', description: 'Executive meeting venue' },
];

const tierColors = {
  platinum: {
    bg: 'from-gray-200 via-gray-100 to-gray-300',
    border: 'border-gray-400',
    text: 'text-gray-800',
    badge: 'bg-gray-800 text-white',
  },
  gold: {
    bg: 'from-yellow-400 via-yellow-300 to-amber-400',
    border: 'border-yellow-600',
    text: 'text-yellow-900',
    badge: 'bg-yellow-600 text-white',
  },
  silver: {
    bg: 'from-gray-300 via-gray-200 to-gray-400',
    border: 'border-gray-500',
    text: 'text-gray-700',
    badge: 'bg-gray-600 text-white',
  },
};

export function Sponsors() {
  const { darkMode } = useTheme();
  const platinumSponsors = sponsors.filter((s) => s.tier === 'platinum');
  const goldSponsors = sponsors.filter((s) => s.tier === 'gold');
  const silverSponsors = sponsors.filter((s) => s.tier === 'silver');

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      {/* Hero */}
      <section
        className={`py-20 ${
          darkMode ? 'bg-gradient-to-br from-gray-900 via-black to-amber-900/10' : 'bg-gradient-to-br from-black via-gray-900 to-amber-900/20'
        }`}
      >
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent">
            Our Sponsors
          </h1>
          <p className="text-xl text-white max-w-3xl mx-auto">
            We're grateful to our partners who make PARAISO possible and share our vision for innovation and excellence
          </p>
        </div>
      </section>

      {/* Platinum Sponsors */}
      <section className={`py-20 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-block px-6 py-2 bg-gray-800 text-white text-sm font-bold rounded-full mb-4">
              PLATINUM SPONSORS
            </div>
            <h2 className={`text-4xl font-bold ${darkMode ? 'text-white' : 'text-black'}`}>Premier Partners</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {platinumSponsors.map((sponsor, index) => (
              <div
                key={index}
                className={`bg-gradient-to-br ${tierColors.platinum.bg} p-8 rounded-lg border-4 ${tierColors.platinum.border} shadow-xl hover:shadow-2xl transition-all`}
              >
                <div className="flex items-center justify-center h-32 mb-6">
                  <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-lg">
                    <span className="text-4xl font-bold text-gray-800">{sponsor.logo}</span>
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-center mb-2 text-gray-800">{sponsor.name}</h3>
                <p className="text-center text-gray-700">{sponsor.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gold Sponsors */}
      <section
        className={`py-20 ${
          darkMode ? 'bg-gradient-to-br from-yellow-900/20 to-amber-900/20' : 'bg-gradient-to-br from-yellow-50 to-amber-50'
        }`}
      >
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-block px-6 py-2 bg-yellow-600 text-white text-sm font-bold rounded-full mb-4">
              GOLD SPONSORS
            </div>
            <h2 className={`text-4xl font-bold ${darkMode ? 'text-white' : 'text-black'}`}>Strategic Partners</h2>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {goldSponsors.map((sponsor, index) => (
              <div
                key={index}
                className={`bg-gradient-to-br ${tierColors.gold.bg} p-6 rounded-lg border-4 ${tierColors.gold.border} shadow-lg hover:shadow-xl transition-all`}
              >
                <div className="flex items-center justify-center h-24 mb-4">
                  <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-md">
                    <span className="text-3xl font-bold text-yellow-700">{sponsor.logo}</span>
                  </div>
                </div>
                <h3 className="text-xl font-bold text-center mb-2 text-yellow-900">{sponsor.name}</h3>
                <p className="text-center text-sm text-yellow-800">{sponsor.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Silver Sponsors */}
      <section className={`py-20 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <div className="inline-block px-6 py-2 bg-gray-600 text-white text-sm font-bold rounded-full mb-4">
              SILVER SPONSORS
            </div>
            <h2 className={`text-4xl font-bold ${darkMode ? 'text-white' : 'text-black'}`}>Supporting Partners</h2>
          </div>
          <div className="grid md:grid-cols-4 lg:grid-cols-6 gap-6">
            {silverSponsors.map((sponsor, index) => (
              <div
                key={index}
                className={`bg-gradient-to-br ${tierColors.silver.bg} p-4 rounded-lg border-2 ${tierColors.silver.border} shadow-md hover:shadow-lg transition-all`}
              >
                <div className="flex items-center justify-center h-20 mb-3">
                  <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow">
                    <span className="text-2xl font-bold text-gray-700">{sponsor.logo}</span>
                  </div>
                </div>
                <h3 className="text-lg font-bold text-center mb-1 text-gray-700">{sponsor.name}</h3>
                <p className="text-center text-xs text-gray-600">{sponsor.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sponsorship Benefits */}
      <section
        className={`py-20 ${
          darkMode ? 'bg-gradient-to-br from-black via-gray-950 to-amber-900/10' : 'bg-gradient-to-br from-gray-900 via-black to-amber-900/20'
        }`}
      >
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-white text-center">Sponsorship Benefits</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white/10 backdrop-blur-sm p-8 rounded-lg border-4 border-gray-400">
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-white mb-2">PLATINUM</div>
                <div className="text-5xl font-bold text-gray-300 mb-4">$50K+</div>
              </div>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start space-x-2">
                  <span className="text-gray-400 mt-1">•</span>
                  <span>Prime exhibition booth (40x40 ft)</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-400 mt-1">•</span>
                  <span>Keynote speaking opportunity</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-400 mt-1">•</span>
                  <span>Logo on all marketing materials</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-400 mt-1">•</span>
                  <span>20 complimentary VIP passes</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-400 mt-1">•</span>
                  <span>Exclusive networking dinner</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-400 mt-1">•</span>
                  <span>Full-page ad in program</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-400 mt-1">•</span>
                  <span>Attendee contact list access</span>
                </li>
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm p-8 rounded-lg border-4 border-yellow-500">
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-white mb-2">GOLD</div>
                <div className="text-5xl font-bold text-yellow-400 mb-4">$25K+</div>
              </div>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start space-x-2">
                  <span className="text-yellow-400 mt-1">•</span>
                  <span>Premium exhibition booth (20x20 ft)</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-yellow-400 mt-1">•</span>
                  <span>Breakout session slot</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-yellow-400 mt-1">•</span>
                  <span>Logo on website & signage</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-yellow-400 mt-1">•</span>
                  <span>10 complimentary passes</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-yellow-400 mt-1">•</span>
                  <span>VIP reception access</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-yellow-400 mt-1">•</span>
                  <span>Half-page ad in program</span>
                </li>
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm p-8 rounded-lg border-4 border-gray-500">
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-white mb-2">SILVER</div>
                <div className="text-5xl font-bold text-gray-400 mb-4">$10K+</div>
              </div>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-start space-x-2">
                  <span className="text-gray-500 mt-1">•</span>
                  <span>Standard exhibition booth (10x10 ft)</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-500 mt-1">•</span>
                  <span>Logo on website</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-500 mt-1">•</span>
                  <span>5 complimentary passes</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-500 mt-1">•</span>
                  <span>Networking events access</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-gray-500 mt-1">•</span>
                  <span>Quarter-page ad in program</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Become a Sponsor CTA */}
      <section className="py-20 bg-gradient-to-br from-yellow-500 via-amber-600 to-yellow-500">
        <div className="container mx-auto px-4">
          <div className="bg-black/20 backdrop-blur-sm rounded-lg p-12 text-center border-2 border-black/30">
            <h2 className="text-5xl font-bold mb-6 text-black">Become a Sponsor</h2>
            <p className="text-xl text-black/80 mb-8 max-w-3xl mx-auto">
              Join leading companies in supporting PARAISO 2026 and gain unparalleled exposure to thousands of industry professionals, decision-makers, and innovators.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4 mb-8">
              <a
                href="mailto:sponsors@paraiso.com"
                className="inline-flex items-center space-x-2 px-8 py-4 bg-black text-yellow-400 font-bold text-lg rounded-lg hover:bg-gray-900 transition-all shadow-lg"
              >
                <Mail className="w-5 h-5" />
                <span>Email Us</span>
              </a>
              <a
                href="tel:+15551234567"
                className="inline-flex items-center space-x-2 px-8 py-4 bg-white text-black font-bold text-lg rounded-lg hover:bg-gray-100 transition-all shadow-lg"
              >
                <Phone className="w-5 h-5" />
                <span>Call Us</span>
              </a>
              <button
                onClick={() => alert('Sponsorship prospectus download would start here')}
                className="inline-flex items-center space-x-2 px-8 py-4 bg-white/20 backdrop-blur-sm text-black font-bold text-lg rounded-lg border-2 border-black/30 hover:bg-white/30 transition-all"
              >
                <FileText className="w-5 h-5" />
                <span>Download Prospectus</span>
              </button>
            </div>
            <div className="text-black/80">
              <p className="mb-2">Contact our sponsorship team:</p>
              <p className="font-semibold">sponsors@paraiso.com | +1 (555) 123-4567</p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Sponsor */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-black text-center">Why Sponsor PARAISO?</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: 'Brand Visibility',
                description: 'Reach 5,000+ attendees and millions through digital channels',
              },
              {
                title: 'Lead Generation',
                description: 'Connect directly with decision-makers and potential clients',
              },
              {
                title: 'Thought Leadership',
                description: 'Position your brand as an industry leader and innovator',
              },
              {
                title: 'Networking',
                description: 'Build relationships with key stakeholders and partners',
              },
            ].map((item, index) => (
              <div key={index} className="bg-gradient-to-br from-yellow-50 to-amber-50 p-8 rounded-lg border-2 border-yellow-200">
                <h3 className="text-2xl font-bold text-black mb-4">{item.title}</h3>
                <p className="text-gray-700">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}